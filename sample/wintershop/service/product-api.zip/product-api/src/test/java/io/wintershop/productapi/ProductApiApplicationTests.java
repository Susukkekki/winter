package io.wintershop.productapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
